import { Customer } from "./Customer";
import { Plant } from "./Plant";

export class Order{

    orderDate:Date;
    totalcost:number;
    plantOrder:Plant[]
    customer:Customer

}