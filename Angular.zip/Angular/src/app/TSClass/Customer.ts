export class Customer{ 
    name:string;
    email:string;
    password:string;
    address:string;
    contactNo:string;
    userId:string
}