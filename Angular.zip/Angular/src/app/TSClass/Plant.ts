export class Plant{
    
    plantId:number;
    commonName:string;
    scientificName:string;
    description:string;
    plantStock:number;
    category:string;
    quantity:number;
    imgurl:string;
    plantPrice:number;
    cart:Plant[];
}