import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { CustomerService } from 'src/app/services/customer.service';
import { Customer } from 'src/app/TSClass/Customer';

@Component({
  selector: 'app-add-customer',
  templateUrl: './add-customer.component.html',
  styleUrls: ['./add-customer.component.css']
})
export class AddCustomerComponent {
  customer:Customer=new Customer();
  constructor(private p:CustomerService,private r:Router) { }

  ngOnInit(): void {
  }

  addcustomer():void{
    console.log(this.customer);

    this.p.addCustomer(this.customer).subscribe(
      (p1)=>{this.customer=p1;
        alert("customer added succesfully");
        this.r.navigate(['/']);
        
      },
      (error) => {
        if (error && error.error && error.error.message) {
          alert(error.error.message);
        } else {
          alert('An error occurred. Please try again later.');
        }
      }
    );

    

  this.customer=new Customer();
  }

}
