import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { OrderService } from 'src/app/services/order.service';
import { PlantService } from 'src/app/services/plant.service';
import { SharedServiceService } from 'src/app/services/shared-service.service';
import { Admin } from 'src/app/TSClass/Admin';
import { Customer } from 'src/app/TSClass/Customer';
import { Order } from 'src/app/TSClass/Order';
import { Plant } from 'src/app/TSClass/Plant';
import { PlantComponent } from '../plant/plant.component';

@Component({
  selector: 'app-customer',
  templateUrl: './customer.component.html',
  styleUrls: ['./customer.component.css']
})
export class CustomerComponent {

  customer:Customer= new Customer();
  cart:Plant [] = []
  listOfPlants: Plant []=[]
  name: string;
  category: string
  Plant: Plant = new Plant()
  order:Order = new Order()

  constructor(private r:Router, private plantService:PlantService, private orderService:OrderService, private s:SharedServiceService){
    this.plantService.getAllPlants().subscribe((pl)=>{this.listOfPlants=pl}
    ,(err:any) => {
      if (err['error'].msg != 'undefined') {
        alert(err['error'].msg);}
      }
    );
    this.customer=s.getCustomer();

  }
  viewall():void{
      
    
    this.plantService.getAllPlants().subscribe((pl)=>{this.listOfPlants=pl}
    ,(err:any) => {
      if (err['error'].msg != 'undefined') {
        alert(err['error'].msg);}
      }
    );
  }
  searchByName():void{
    this.plantService.searchByName(this.name).subscribe((res)=>{this.listOfPlants=res},
    (err:any)=>{
      if(err['error'].msg != 'undefined'){
        alert(err['error'].msg);
      }
    })
  }
  searchByCategory():void{
    this.plantService.searchByCategory(this.category).subscribe((res)=>{this.listOfPlants=res},
    (err:any)=>{
      if(err['error'].msg != 'undefined'){
        alert(err['error'].msg);
      }
    })
  }
  addToCart(selectedPlant:Plant):void{
    this.cart.push(selectedPlant);
    this.orderService.setCurrentOrder(selectedPlant);
    console.log(this.orderService.getCurrentCart());
  }
  createNewOrder():void{
    this.orderService.addOrder(this.order).subscribe((res)=>{this.order=res},
    (err:any)=>{
      if(err['error'].msg != 'undefined'){
        alert(err['error'].msg);
      }
    })
  }
  goToOrder():void{
    this.r.navigate(['/order']);
  }
  logout():void{
    this.s.setAdmin(new Admin())
    this.s.setCustomer(new Customer())
    this.r.navigate(['/']);
   
  
  }



}
