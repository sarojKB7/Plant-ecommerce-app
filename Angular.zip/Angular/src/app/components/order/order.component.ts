import { Component } from '@angular/core';
import { Route, Router } from '@angular/router';
import { OrderService } from 'src/app/services/order.service';
import { SharedServiceService } from 'src/app/services/shared-service.service';
import { Order } from 'src/app/TSClass/Order';
import { Plant } from 'src/app/TSClass/Plant';

@Component({
  selector: 'app-order',
  templateUrl: './order.component.html',
  styleUrls: ['./order.component.css']
})
export class OrderComponent {
  hashmap = new Map<Plant, number>();
  cart: Plant[] =[]
  totalCost: number = 0;
  order:Order = new Order()

  constructor(private r:Router,private orderService:OrderService,private s:SharedServiceService){
    this.cart=this.orderService.getCurrentCart()
    this.hashing()
    console.log(this.hashmap)
    this.calculateCost()
  }
  orderPlaced():void{

    //this.order.orderDate=new Date()
    this.order.totalcost=this.totalCost
    this.order.customer=this.s.getCustomer()
    this.order.plantOrder=this.cart
    this.orderService.addOrder(this.order).subscribe((res)=>{
      this.order=res;
      alert("Your order has been placed. Thank you for shopping with us");
      this.r.navigate(['/customer'])
         
    })
  }

  hashing(){
    for (const item of this.cart) {
      if (this.hashmap.has(item)) {
        this.hashmap.set(item, this.hashmap.get(item)! + 1);
      } else {
        this.hashmap.set(item, 1);
      }
    }
  }
  calculateCost(){
    for(const p of this.cart){
      this.totalCost += p.plantPrice
    }
  }
  

}
