import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { CustomerService } from 'src/app/services/customer.service';
import { PlantService } from 'src/app/services/plant.service';
import { Customer } from 'src/app/TSClass/Customer';
import { Plant } from 'src/app/TSClass/Plant';

@Component({
  selector: 'app-plant',
  templateUrl: './plant.component.html',
  styleUrls: ['./plant.component.css']
})
export class PlantComponent {
  tableshow:boolean=false;
  check:boolean=true;
  id:number;
  commonName:string;
  type:string;
 
  plants:Plant[]=[];
  plant:Plant=new Plant();
  planttt:Plant=new Plant();

  constructor(private p:PlantService,private r:Router) { 
    
  }

  ngOnInit(): void {
  }


  deletePlant(id:number):void{
    this.p.deletePlant(id).subscribe((pl)=>{
      this.plant=pl;
      this.viewall();
      alert('Plant deleted successfully');
    });
  }

  modify(p:Plant):void{
    this.check=false;
    this.plant=p;
  }

  viewPlantById():void{
    this.plants=[];
    this.p.searchById(this.id).subscribe((p1)=>this.plants.push(p1)
    ,
    (err:any) => {
          
      if (err['error'].msg != 'undefined') {
        
        alert(err['error'].msg);
        
      }
      

  });

  }

  viewPlantByCommonName():void{
    this.plants=[];
      this.p.searchByName(this.commonName).subscribe((p1)=>this.plants=(p1)
      ,
    (err:any) => {
          
      if (err['error'].msg != 'undefined') {
        
        alert(err['error'].msg);
        
      }
      

  });

  
  }

  viewPlantBytype():void{
    this.p.searchByCategory(this.type).subscribe((p1)=>this.plants=p1
    ,
    (err:any) => {
          
      if (err['error'].msg != 'undefined') {
        
        alert(err['error'].msg);
        
      }
      

  });
    
  }

  viewall():void{
      
    
    this.p.getAllPlants().subscribe((pl)=>{this.plants=[];
      this.plants=pl;
      this.tableshow=true;
    }
    ,
    (err:any) => {
          
      if (err['error'].msg != 'undefined') {
        
        alert(err['error'].msg);
        
      }
      

  });

  }

  addPlant():void{
    this.p.addPlant(this.plant).subscribe(
      (p1)=>{this.planttt=p1,
        alert('Plant added successfully!!!!')
      },
    (err:any) => {
          
      if (err['error'].msg != 'undefined') {
        
        alert(err['error'].msg);
        
      }
      

  }
    );

  

    

    this.plant=new Plant();

    


}

modPlant():void{
  this.p.updatePlant(this.plant).subscribe(
    (p1)=>this.planttt=p1,
  (err:any) => {
        
    if (err['error'].msg != 'undefined') {
      
      alert(err['error'].msg);
      
    }
    

}
  );



  

  this.plant=new Plant();

}

add():void
{
  this.check=true;
}

back():void{
  
  this.r.navigate(['/adminhome']);
}
}



