import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { AdminService } from 'src/app/services/admin.service';
import { CustomerService } from 'src/app/services/customer.service';
import { SharedServiceService } from 'src/app/services/shared-service.service';
import { Admin } from 'src/app/TSClass/Admin';
import { Customer } from 'src/app/TSClass/Customer';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent {
  checkadmin:boolean=false;
  UserName:string;
  Password:string;
  admin:Admin;
  customer:Customer;


  constructor(private r:Router,private m:AdminService,private s:SharedServiceService, private c:CustomerService) { }

  ngOnInit(): void {
  }

  loginadmin():void{
    this.m.adminLogin(this.UserName,this.Password).subscribe( (a)=>this.admin=a ,
        (err:any) => {
          
          if (err['error'].msg != 'undefined') {
            
            alert(err['error'].msg);
            this.UserName='';
            this.Password='';
          }

          
        }
        );

        if(this.admin!=null){
          console.log(this.admin.adminId);
          this.s.setAdmin(this.admin);
          this.r.navigate(['/admin']);
        }
        
       
  }

  loginCustomer():void{
    
    this.c.validate(this.UserName,this.Password).subscribe( (a)=>this.customer=a ,
        (err:any) => {
          
          if (err['error'].msg != 'undefined') {
            
            alert(err['error'].msg);
            this.UserName='';
            this.Password='';
          }

          
        }
        );
        

        if(this.customer!=null){
          
          
          this.s.setCustomer(this.customer);
          //important for data sharing
 this.r.navigate(['/customer']);
        }
        
        
       
  

}

  myfun():void{
    if(this.checkadmin==true)
        this.checkadmin=false;
    else
        this.checkadmin=true;

  }

}
