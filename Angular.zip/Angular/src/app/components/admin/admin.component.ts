import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { PlantService } from 'src/app/services/plant.service';
import { SharedServiceService } from 'src/app/services/shared-service.service';
import { Admin } from 'src/app/TSClass/Admin';
import { Customer } from 'src/app/TSClass/Customer';
import { Plant } from 'src/app/TSClass/Plant';

@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.css']
})
export class AdminComponent {
  tableshow:boolean=false;
  check:boolean=true;
  updatebtn:boolean=false;
  id:number;
  name:string;
  category:string;
 
  listOfPlants:Plant[]=[];
  plant:Plant=new Plant();
  newplant:Plant=new Plant();

  constructor(private p:PlantService,private s:SharedServiceService, private r:Router) { 
    this.viewall()
    
  }

  ngOnInit(): void {
  }


  deletePlant(plantid:number):void{
    
    // this.listOfPlants=[];
    this.p.deletePlant(plantid).subscribe((pl)=>{
      this.plant=pl;
      this.viewall();
      alert('Plant deleted successfully');
    },
    (err:any) => {
          
      if (err['error'].msg != 'undefined') {
        
        alert(err['error'].msg);
        
      }
      

  });
    
  }

  modify(p:Plant):void{
    this.plant=new Plant()
    this.check=false;
    this.plant=p;
    this.updatebtn=true
  }

  viewPlantById():void{
    this.listOfPlants=[];
    this.p.searchById(this.id).subscribe((p1)=>this.listOfPlants.push(p1)
    ,
    (err:any) => {
          
      if (err['error'].msg != 'undefined') {
        
        alert(err['error'].msg);
        
      }
      

  });

  }

  searchByName():void{
    this.listOfPlants=[];
      this.p.searchByName(this.name).subscribe((p1)=>this.listOfPlants=(p1)
      ,
    (err:any) => {
          
      if (err['error'].msg != 'undefined') {
        
        alert(err['error'].msg);
        
      }
      

  });

  
  }

  searchByCategory():void{
    this.p.searchByCategory(this.category).subscribe((p1)=>this.listOfPlants=p1
    ,
    (err:any) => {
          
      if (err['error'].msg != 'undefined') {
        
        alert(err['error'].msg);
        
      }
      

  });
    
  }

  viewall():void{
      
    
    this.p.getAllPlants().subscribe((pl)=>{
      this.listOfPlants=pl;
      
    }
    ,
    (err:any) => {
          
      if (err['error'].msg != 'undefined') {
        
        alert(err['error'].msg);
        
      }
      

  });
  console.log(this.listOfPlants)

  }

  addPlant():void{
    this.p.addPlant(this.plant).subscribe(
      (p1)=>{this.newplant=p1;
        this.viewall();
        alert('Plant added successfully!!!!')
      },
    (err:any) => {
          
      if (err['error'].msg != 'undefined') {
        
        alert(err['error'].msg);
        
      }
      

  }
    );

  

    

    this.plant=new Plant();

    


}

modPlant():void{
  this.p.updatePlant(this.plant).subscribe(
    (p1)=>this.plant=p1,
  (err:any) => {
        
    if (err['error'].msg != 'undefined') {
      
      alert(err['error'].msg);
      
    }
    

}
  );



  
  this.updatebtn=false;
  this.plant=new Plant();

}

add():void
{
  this.check=true;
}

logout():void{
  this.s.setAdmin(new Admin())
  this.s.setCustomer(new Customer())
  this.r.navigate(['/']);
 

}
}


