import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Order } from '../TSClass/Order';
import { Plant } from '../TSClass/Plant';

@Injectable({
  providedIn: 'root'
})
export class OrderService {
  currentCart:Plant[] = []

  OrderUrl: string = "http://localhost:8080/order";

  constructor(private http:HttpClient) { }

  viewAllOrder(): Observable<any[]> {
    return this.http.get<any[]>(this.OrderUrl+'/viewallorders');
  }

  addOrder(Order: Order): Observable<any> {
    return  this.http.post( this.OrderUrl + '/add', Order,{responseType:"text"});
  }

  updateOrder(Order: Order): Observable<any> {
    return  this.http.post( this.OrderUrl + '/update', Order,{responseType:"text"});
  }

  deleteOrder(id: number): Observable<any> {
    return  this.http.delete( this.OrderUrl + '/delete/'+id);
  }

  searchOrderByCustomerId(id: number): Observable<any[]>{
    return  this.http.get<any[]>(this.OrderUrl+'/searchbycustomerid/'+id);
  }

  setCurrentOrder(plant:Plant){
    this.currentCart.push(plant)
  }
  getCurrentCart(){
    return this.currentCart
  }
  
}
