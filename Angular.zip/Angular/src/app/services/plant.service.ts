import { HttpClient, HttpResponse } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Plant } from '../TSClass/Plant';
import { map } from 'rxjs/operators'

@Injectable({
  providedIn: 'root'
})
export class PlantService {

  plantUrl: string = 'http://localhost:8080/plant';

  constructor(private h:HttpClient) { }

  getAllPlants():Observable<Plant[]> {
    return this.h.get<Plant[]>(this.plantUrl+'/viewallplants')
  }
  

  addPlant(plant: Plant): Observable<any> {
    return  this.h.post( this.plantUrl + '/add', plant,{responseType:"text"});
  }

  updatePlant(plant: Plant): Observable<any> {
    return  this.h.put( this.plantUrl + '/update', plant,{responseType:"text"});
  }

  deletePlant(id: number): Observable<any> {
    return  this.h.delete( this.plantUrl + '/delete/'+id);
  }

  searchById(id: number): Observable<any> {
    return this.h.get<any>(this.plantUrl+'/searchbyid/'+id);
  }

  searchByName(name: string): Observable<any[]> {
    return this.h.get<any[]>(this.plantUrl+'/searchbyname/'+name);
  }

  searchByCategory(category: string): Observable<any[]> {
    return this.h.get<any[]>(this.plantUrl+'/searchbycategory/'+category);
  }



}
