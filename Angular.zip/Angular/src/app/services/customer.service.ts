import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Customer } from '../TSClass/Customer';

@Injectable({
  providedIn: 'root'
})
export class CustomerService {

  customerUrl: string = "http://localhost:8080/customer";

  constructor(private http:HttpClient) { }

  viewAllCustomer(): Observable<any[]> {
    return this.http.get<any[]>(this.customerUrl+'/viewallCustomers');
  }

  addCustomer(customer: Customer): Observable<any> {
    return  this.http.post( this.customerUrl + '/add', customer,{responseType:"text"});
  }

  updateCustomer(Customer: Customer): Observable<any> {
    return  this.http.post( this.customerUrl + '/update', Customer,{responseType:"text"});
  }

  deleteCustomer(id: number): Observable<any> {
    return  this.http.delete( this.customerUrl + '/delete/'+id);
  }

  validate(username: string, password: string): Observable<any> {
    return this.http.get<any>(this.customerUrl+'/validate/'+username+'/'+password);
  }


}
