import { Injectable } from '@angular/core';
import { Admin } from '../TSClass/Admin';
import { Customer } from '../TSClass/Customer';

@Injectable({
  providedIn: 'root'
})
export class SharedServiceService {

  currentCustomer : Customer;
  admin:Admin;

  constructor() { }

  setCustomer(c:Customer):void{
    this.currentCustomer=c;
  }
  getCustomer():Customer{
    return this.currentCustomer;
  }
  setAdmin(c:Admin):void{
    this.admin=c;
  }
  getAdmin():Admin{
    return this.admin;
  }
  
}
