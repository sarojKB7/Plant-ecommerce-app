import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AddCustomerComponent } from './components/add-customer/add-customer.component';
import { AdminComponent } from './components/admin/admin.component';
import { CustomerComponent } from './components/customer/customer.component';
import { LoginComponent } from './components/login/login.component';
import { OrderComponent } from './components/order/order.component';
import { PlantComponent } from './components/plant/plant.component';

const routes: Routes = [
  
  {path : 'plant', component:PlantComponent },
  {path : '', component:LoginComponent},
  {path : 'customer', component:CustomerComponent},
  {path : 'register', component:AddCustomerComponent},
  {path : 'order', component:OrderComponent},
  {path : 'admin', component:AdminComponent}
  
  
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
