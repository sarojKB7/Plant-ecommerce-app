import { Component } from '@angular/core';
import { CustomerService } from './services/customer.service';
import { Customer } from './TSClass/Customer';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'Nursery';

  curr : Customer []= []; 

  // constructor(private s:CustomerService){
  //     this.s.viewAllCustomer().subscribe((p1)=>this.curr = p1);
  //     console.log(this.curr);
  // }
}
