package com.poc.nursery.exception;

@SuppressWarnings("serial")
public class AdminException extends Exception {
	public AdminException(String msg) {
		super(msg);
	}
}
