package com.poc.nursery.model;

import java.time.LocalDate;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonFormat;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;

@Entity
@Table(name="Orders_tbl")
public class Order {
	
	@Id
	@GeneratedValue(generator = "order_seq", strategy = GenerationType.SEQUENCE)
	@SequenceGenerator(name="order_seq",sequenceName = "order_id_seq", allocationSize = 1)
	private Integer orderId;
	
	@JsonFormat(pattern = "dd-MM-yyyy")
	private LocalDate orderDate;
	
	@Column
	private double totalcost;
	
	@ManyToMany(cascade = CascadeType.ALL)
	private List<Plant> plantOrder;
	
	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name="customerId", nullable = false)
	private Customer customer;


	private Order() {
		super();
	}

	

	private Order(Integer orderId, LocalDate orderDate, double totalcost, List<Plant> plantOrder, Customer customer) {
		super();
		this.orderId = orderId;
		this.orderDate = orderDate;
		this.totalcost = totalcost;
		this.plantOrder = plantOrder;
		this.customer = customer;
	}



	public Integer getOrderId() {
		return orderId;
	}

	public void setOrderId(Integer orderId) {
		this.orderId = orderId;
	}

	public LocalDate getOrderDate() {
		return orderDate;
	}

	public void setOrderDate(LocalDate orderDate) {
		this.orderDate = orderDate;
	}

	public double getTotalcost() {
		return totalcost;
	}

	public void setTotalcost(double totalcost) {
		this.totalcost = totalcost;
	}



	public Customer getCustomer() {
		return customer;
	}



	public void setCustomer(Customer customer) {
		this.customer = customer;
	}



	public List<Plant> getPlantOrder() {
		return plantOrder;
	}

	public void setPlantOrder(List<Plant> plantOrder) {
		this.plantOrder = plantOrder;
	}



	@Override
	public String toString() {
		return "customer=" + customer + "]";
	}
	
	
	

}
