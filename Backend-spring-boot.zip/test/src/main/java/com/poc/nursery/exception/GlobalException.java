package com.poc.nursery.exception;

import java.time.LocalDateTime;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;

import jakarta.servlet.http.HttpServletRequest;

@ControllerAdvice
public class GlobalException {
	
	@ExceptionHandler(PlantException.class)
	public @ResponseBody ResponseEntity<ErrorInfo> SeedExceptionHandling(PlantException e, HttpServletRequest req){
		ErrorInfo info = new ErrorInfo(LocalDateTime.now(), e.getMessage(), req.getRequestURI());
		return new ResponseEntity<ErrorInfo>(info, HttpStatus.NOT_ACCEPTABLE);
	}
	
	@ExceptionHandler(OrderException.class)
	public @ResponseBody ResponseEntity<ErrorInfo> OrderExcceptionHandling(OrderException e, HttpServletRequest req){
		ErrorInfo info = new ErrorInfo(LocalDateTime.now(), e.getMessage(), req.getRequestURI());
		return new ResponseEntity<ErrorInfo>(info, HttpStatus.NOT_ACCEPTABLE);
	}
	
	@ExceptionHandler(CustomerException.class)
	public @ResponseBody ResponseEntity<ErrorInfo> CustomerExceptionHandling(CustomerException e, HttpServletRequest req){
		ErrorInfo info = new ErrorInfo(LocalDateTime.now(), e.getMessage(), req.getRequestURI());
		return new ResponseEntity<ErrorInfo>(info, HttpStatus.UNPROCESSABLE_ENTITY);
	}
	
	@ExceptionHandler(AdminException.class)
	public @ResponseBody ResponseEntity<ErrorInfo> AdminExceptionHandling(AdminException e, HttpServletRequest req){
		ErrorInfo info = new ErrorInfo(LocalDateTime.now(), e.getMessage(), req.getRequestURI());
		return new ResponseEntity<ErrorInfo>(info, HttpStatus.NOT_ACCEPTABLE);
	}

}
