package com.poc.nursery.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.poc.nursery.model.Customer;

@Repository
public interface ICustomerRepo extends JpaRepository<Customer, Integer> {
	
		@Query("select c from Customer c where c.userId =:userid and c.password =:password")
		public Customer  customerLogin(@Param("userid") String userid, @Param("password") String password);
	
		@Query("select c from Customer c where c.userId =:userid and c.password =:password")
		public List<Customer>  getAllCustomerWithGivenCred(@Param("userid") String userid, @Param("password") String password);
	
}
