package com.poc.nursery.model;

import java.util.List;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;

@Entity
@Table(name = "plant")
public class Plant {
	
	@Id
	@GeneratedValue(generator = "plant_seq", strategy = GenerationType.SEQUENCE)
	@SequenceGenerator(name="plant_seq", sequenceName = "plantId_seq", allocationSize = 1)
	private Integer plantId;
	
	@Column(length=30)
	private String commonName;
	
	@Column(length=30)
	private String scientificName;
	
	@Column
	private String description;
	
	@Column
	private Integer plantStock;
	
	@Column
	private String category;
	
	@Column
	private Integer quantity;
	
	@Column
	private String imgurl;
	
	@Column
	private Integer  plantPrice;
	
	@ManyToMany(mappedBy = "plantOrder",cascade = CascadeType.ALL)
	private List<Order> cart;
	
	
	
	

	private Plant() {
		super();
	}





	private Plant(Integer plantId, String commonName, String scientificName, String description, Integer plantStock,
			String category, Integer quantity, String imgurl, Integer plantPrice) {
		super();
		this.plantId = plantId;
		this.commonName = commonName;
		this.scientificName = scientificName;
		this.description = description;
		this.plantStock = plantStock;
		this.category = category;
		this.quantity = quantity;
		this.plantPrice = plantPrice;
		this.imgurl = imgurl;
	}





	public String getImgurl() {
		return imgurl;
	}





	public void setImgurl(String imgurl) {
		this.imgurl = imgurl;
	}





	public Integer getPlantId() {
		return plantId;
	}





	public void setPlantId(Integer plantId) {
		this.plantId = plantId;
	}





	public String getCommonName() {
		return commonName;
	}





	public void setCommonName(String commonName) {
		this.commonName = commonName;
	}





	public String getScientificName() {
		return scientificName;
	}





	public void setScientificName(String scientificName) {
		this.scientificName = scientificName;
	}





	public String getDescription() {
		return description;
	}





	public void setDescription(String description) {
		this.description = description;
	}





	public Integer getPlantStock() {
		return plantStock;
	}





	public void setPlantStock(Integer plantStock) {
		this.plantStock = plantStock;
	}





	public String getCategory() {
		return category;
	}





	public void setCategory(String category) {
		this.category = category;
	}





	public Integer getQuantity() {
		return quantity;
	}





	public void setQuantity(Integer quantity) {
		this.quantity = quantity;
	}





	public Integer getPlantPrice() {
		return plantPrice;
	}





	public void setPlantPrice(Integer plantPrice) {
		this.plantPrice = plantPrice;
	}
	
	


	
	
	

}
