package com.poc.nursery.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.poc.nursery.exception.CustomerException;
import com.poc.nursery.exception.OrderException;
import com.poc.nursery.model.Order;
import com.poc.nursery.service.OrderService;

@RestController
@RequestMapping("/order")
@CrossOrigin("*")
public class OrderController {
	@Autowired
	OrderService service;
	
	@PostMapping("/add")
	public ResponseEntity<Order> addOrder(@RequestBody Order order) throws OrderException{
		return service.addOrder(order);
	}
	
	@GetMapping("/viewallorders")
	public ResponseEntity<List<Order>> viewAllOrder() throws OrderException{
		return service.viewAllOrders();
	}
	
	@PutMapping("/update")
	public ResponseEntity<Order> updateOrder(@RequestBody Order order) throws OrderException{
		return service.updateOrder(order);
	}
	
	@DeleteMapping("/delete/{id}")
	public ResponseEntity<Order> deleteOrder(@PathVariable("id") Integer id) throws OrderException{
		return service.deleteOrder(id);
	}
	
//	@GetMapping("/searchbyid/{id}")
//	public ResponseEntity<Order> searchById(@PathVariable("id") Integer id) throws OrderException{
//		return service.getOrderById(id);
//	}
//	
//	@GetMapping("/searchbyname/{commonName}")
//	public ResponseEntity<List<Order>> searchByName(@PathVariable("commonName") String commonName) throws OrderException{
//		return service.getOrderByName(commonName);
//	}
	
	@GetMapping("/searchbycustomerid/{id}")
	public ResponseEntity<List<Order>> searchByCustomerId(@PathVariable("id") Integer id) throws OrderException, CustomerException{
		return service.searchOrderByCustomerId(id);
	}


}
