package com.poc.nursery.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.poc.nursery.model.Admin;

@Repository
public interface IAdminRepo extends JpaRepository<Admin, String> {
	
	@Query("select c from Admin c where c.adminId =:userid and c.password =:password")
	public Admin  AdminAuthentication(@Param("userid") String userid, @Param("password") String password);


}
