package com.poc.nursery.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.poc.nursery.exception.PlantException;
import com.poc.nursery.model.Plant;
import com.poc.nursery.repository.IPlantRepo;

@Service
public class PlantService {
	
	@Autowired
	IPlantRepo repository;
	
	//To add a plant to database
	public ResponseEntity<Plant> addplant(Plant plant) throws PlantException{
		if( plant.getScientificName() == null || plant.getPlantPrice() == null) {
			throw new PlantException("Enter all required details");
		}
			
		repository.save(plant);
		return new ResponseEntity<Plant>(plant, HttpStatus.CREATED);
	}
	
	//update plant details to database
	public ResponseEntity<Plant> updateplant(Plant plant){
		repository.save(plant);
		return new ResponseEntity<Plant>(plant, HttpStatus.CREATED);
		
	}
	
	//delete a plant 
	public ResponseEntity<Plant> deleteplant(Integer id) throws PlantException{
		if(!repository.existsById(id)) {
			throw new PlantException("This Plant doesn't exist");
		}
		Plant plant=repository.findById(id).get();
		repository.deleteById(id);
		return  new ResponseEntity<Plant>(plant,  HttpStatus.OK);
	}
	//view all plants
	public ResponseEntity<List<Plant>> viewAllplant() throws PlantException{
		List<Plant> allplants = repository.findAll();
		return  new ResponseEntity<List<Plant>>(allplants,  HttpStatus.OK);
	}
	
	public ResponseEntity<Plant> getplantById(Integer id) throws PlantException{
		if(!repository.existsById(id)) {
			throw new PlantException("This Plant with this Id doesn't exist");
		}
		Plant plant = repository.findById(id).get();
		return new ResponseEntity<Plant>(plant,  HttpStatus.OK);
	}
	
	public ResponseEntity<List<Plant>> getplantByName(String commonName) throws PlantException{
		List<Plant> allplants = repository.viewByName(commonName);
		if ( allplants.size() == 0) {
			throw new PlantException("No plant exits with this name");
		}
		return  new ResponseEntity<List<Plant>>(allplants,  HttpStatus.OK);
		
	}
	
	public ResponseEntity<List<Plant>> getplantByCategory(String category) throws PlantException{
		List<Plant> allplants = repository.viewByCategory(category);
		if ( allplants.size() == 0) {
			throw new PlantException("No plant exits with this category");
		}
		return  new ResponseEntity<List<Plant>>(allplants,  HttpStatus.OK);
		
	}

}
