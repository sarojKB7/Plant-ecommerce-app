package com.poc.nursery.exception;

@SuppressWarnings("serial")
public class CustomerException extends Exception{
	public CustomerException(String msg) {
		super(msg);
	}

}
