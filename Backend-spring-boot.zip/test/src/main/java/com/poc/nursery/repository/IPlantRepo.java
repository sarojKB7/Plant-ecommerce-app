package com.poc.nursery.repository;



import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.poc.nursery.model.Plant;

@Repository
public interface IPlantRepo extends JpaRepository<Plant, Integer>  {
	
	@Query("select p from Plant p where p.commonName=:name")
	List<Plant> viewByName(@Param("name") String  commonName);
	
	@Query("select p from Plant p where p.category=:name")
	List<Plant> viewByCategory(@Param("name") String  category);
	
	

}
