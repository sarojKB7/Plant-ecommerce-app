package com.poc.nursery.exception;

@SuppressWarnings("serial")
public class OrderException extends Exception {
	
	public OrderException(String msg) {
		super(msg);
	}

}
