package com.poc.nursery.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.poc.nursery.exception.CustomerException;
import com.poc.nursery.exception.OrderException;
import com.poc.nursery.model.Customer;
import com.poc.nursery.model.Order;
import com.poc.nursery.model.Plant;
import com.poc.nursery.repository.ICustomerRepo;
import com.poc.nursery.repository.IOrderRepo;
import com.poc.nursery.repository.IPlantRepo;

import jakarta.transaction.Transactional;

@Service
public class OrderService {
	
	@Autowired
	IOrderRepo repo;
	
	@Autowired
	IPlantRepo plantrepo;
	
	@Autowired
	ICustomerRepo custrepo;
	
	public  double calculateTotalCost(List<Plant> plants) {
		double cost = 0;
		for(Plant p: plants) {
			cost += p.getPlantPrice();
		}
		
		return cost;
	}
	
	//add order
	@Transactional
	public ResponseEntity<Order> addOrder(Order order) throws OrderException{
		if(order.getPlantOrder().size() <= 0) {
			throw new OrderException("No items found in the order");
		}
		List<Plant> plants = order.getPlantOrder();
		List<Plant>  managedPlants = new ArrayList<>();
		for (Plant plant:plants) {
			Plant managedPlant = plantrepo.findById(plant.getPlantId()).orElse(null);
			if( managedPlant!=null) {
				managedPlants.add(managedPlant);
			}
		}
		order.setPlantOrder(managedPlants);
		
		order.setTotalcost(calculateTotalCost(managedPlants));
		
		Customer customer = custrepo.findById(order.getCustomer().getCustomerId()).get();
		System.out.println(customer);
		
		order.setCustomer(customer);
		
		
		repo.save(order);
		return new ResponseEntity<Order>(order, HttpStatus.CREATED);
	}
	
	
	
	//update order
	public ResponseEntity<Order> updateOrder(Order order) throws OrderException{
		if(order.getPlantOrder().size() <= 0) {
			throw new OrderException("No items found in the order");
		}
		repo.save(order);
		return new ResponseEntity<Order>(order, HttpStatus.CREATED);
	}
	
	
	
	//delete order
	public ResponseEntity<Order> deleteOrder(Integer id) throws OrderException{
		if(!repo.existsById(id)) {
			throw new OrderException("the order doesn't exits");
		}
		Order deleted= repo.findById(id).get();
		repo.deleteById(id);
		return new ResponseEntity<Order>(deleted, HttpStatus.CREATED);
	}
	
	
	//view orders by customer id
	public ResponseEntity<List<Order>> searchOrderByCustomerId(Integer id) throws OrderException,CustomerException{
		if(!custrepo.existsById(id)) {
			throw new CustomerException("Customer not found");
		}
		List<Order> orders = repo.viewByCustomerId(id) ;
		if(orders.size()==0) {
			throw new OrderException("no previous orders found");
		}
		return new ResponseEntity<List<Order>>(orders, HttpStatus.OK);
		
	}
	//view all orders
	
	public ResponseEntity<List<Order>> viewAllOrders(){
		List<Order> orders = repo.findAll();
		return new ResponseEntity<List<Order>>(orders, HttpStatus.OK);
		
	}
	//calculate total cost
	


}
