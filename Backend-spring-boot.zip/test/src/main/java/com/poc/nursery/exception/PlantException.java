package com.poc.nursery.exception;

@SuppressWarnings("serial")
public class PlantException extends Exception{
	
	public PlantException ( String msg) {
		super( msg );
	}

}
