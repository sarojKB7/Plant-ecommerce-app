package com.poc.nursery.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.poc.nursery.exception.CustomerException;
import com.poc.nursery.model.Customer;
import com.poc.nursery.service.CustomerService;

@RestController
@RequestMapping("/customer")
@CrossOrigin("*")
public class CustomerController {
	@Autowired
	CustomerService service;
	
	@PostMapping("/add")
	public ResponseEntity<Customer> addCustomer(@RequestBody Customer customer) throws CustomerException{
		return service.addCustomer(customer);
	}
	
	@GetMapping("/viewallCustomers")
	public ResponseEntity<List<Customer>> viewAllCustomer() throws CustomerException{
		return service.viewAllCustomer();
	}
	
	@PutMapping("/update")
	public ResponseEntity<Customer> updateCustomer(@RequestBody Customer customer) throws CustomerException{
		return service.updateCustomer(customer);
	}
	
	@DeleteMapping("/delete/{id}")
	public ResponseEntity<String> deleteCustomer(@PathVariable("id") Integer id) throws CustomerException{
		return service.deleteCustomer(id);
	}
	
	@GetMapping("/searchbyid/{id}")
	public ResponseEntity<Customer> searchById(@PathVariable("id") Integer id) throws CustomerException{
		return service.getCustomerById(id);
	}
	@GetMapping("/validate/{userid}/{password}")
	public ResponseEntity<Customer> customerLogin(@PathVariable("userid") String userid,@PathVariable("password") String password) throws CustomerException{
		return service.validateCustomer(userid, password);
	}
//	
//	@GetMapping("/searchbyname/{Name}")
//	public ResponseEntity<List<Customer>> searchByName(@PathVariable("Name") String Name) throws CustomerException{
//		return service.getCustomerByName(Name);
//	}

}
