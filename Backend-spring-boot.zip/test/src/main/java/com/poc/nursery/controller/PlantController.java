package com.poc.nursery.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.poc.nursery.exception.PlantException;
import com.poc.nursery.model.Plant;
import com.poc.nursery.service.PlantService;

@RestController
@RequestMapping("/plant")
@CrossOrigin("*")
public class PlantController {
	
	@Autowired
	PlantService service;
	
	@PostMapping("/add")
	public ResponseEntity<Plant> addPlant(@RequestBody Plant seed) throws PlantException{
		return service.addplant(seed);
	}
	
	@GetMapping("/viewallplants")
	public ResponseEntity<List<Plant>> viewAllPlant() throws PlantException{
		return service.viewAllplant();
	}
	
	@PutMapping("/update")
	public ResponseEntity<Plant> updatePlant(@RequestBody Plant seed) throws PlantException{
		return service.updateplant(seed);
	}
	
	@DeleteMapping("/delete/{id}")
	public ResponseEntity<Plant> deletePlant(@PathVariable("id") Integer id) throws PlantException{
		return service.deleteplant(id);
	}
	
	@GetMapping("/searchbyid/{id}")
	public ResponseEntity<Plant> searchById(@PathVariable("id") Integer id) throws PlantException{
		return service.getplantById(id);
	}
	
	@GetMapping("/searchbyname/{commonName}")
	public ResponseEntity<List<Plant>> searchByName(@PathVariable("commonName") String commonName) throws PlantException{
		return service.getplantByName(commonName);
	}
	
	@GetMapping("/searchbycategory/{category}")
	public ResponseEntity<List<Plant>> searchByCategory(@PathVariable("category") String category) throws PlantException{
		return service.getplantByCategory(category);
	}

}
