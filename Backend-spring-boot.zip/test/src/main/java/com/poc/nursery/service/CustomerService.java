package com.poc.nursery.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.poc.nursery.exception.CustomerException;
import com.poc.nursery.model.Customer;
import com.poc.nursery.repository.ICustomerRepo;

@Service
public class CustomerService {
	
	@Autowired
	ICustomerRepo repository;
	
	
		
		//To add a Customer to database
		public ResponseEntity<Customer> addCustomer(Customer customer) throws CustomerException{
			if( customer.getName() == null || customer.getPassword()== null || customer.getContactNo()==null) {

				throw new CustomerException("Enter all required details");
			}
			if(repository.getAllCustomerWithGivenCred(customer.getUserId(), customer.getPassword()).size() >= 1)
				throw new CustomerException("those userid and password already exist");
				
			repository.save(customer);
			return new ResponseEntity<Customer>(customer, HttpStatus.CREATED);
		}
		
		//update Customer details to database
		public ResponseEntity<Customer> updateCustomer(Customer customer){
			repository.save(customer);
			return new ResponseEntity<Customer>(customer, HttpStatus.CREATED);
			
		}
		
		//delete a Customer 
		public ResponseEntity<String> deleteCustomer(Integer id) throws CustomerException{
			if(!repository.existsById(id)) {
				throw new CustomerException("This Customer doesn't exist");
			}
			repository.deleteById(id);
			return  new ResponseEntity<String>("Customer deleted successfully",  HttpStatus.OK);
		}
		//view all Customers
		public ResponseEntity<List<Customer>> viewAllCustomer() throws CustomerException{
			List<Customer> allCustomers = repository.findAll();
			if ( allCustomers.size() == 0) {
				throw new CustomerException("No Customer exits");
			}
			return  new ResponseEntity<List<Customer>>(allCustomers,  HttpStatus.OK);
		}
		
		public ResponseEntity<Customer> getCustomerById(Integer id) throws CustomerException{
			if(!repository.existsById(id)) {
				throw new CustomerException("This Customer with this Id doesn't exist");
			}
			Customer Customer = repository.findById(id).get();
			return new ResponseEntity<Customer>(Customer,  HttpStatus.OK);
		}
		
		public ResponseEntity<Customer> validateCustomer(String userid,String password ) throws CustomerException{
			Customer customer = repository.customerLogin(userid, password);
			if(customer == null) 
				throw new CustomerException("invalid credentials");
			return new ResponseEntity<Customer>(customer, HttpStatus.OK);
		}


}
