package com.poc.nursery.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.poc.nursery.exception.AdminException;
import com.poc.nursery.model.Admin;
import com.poc.nursery.repository.IAdminRepo;

@Service
public class AdminService {
	@Autowired
	IAdminRepo repository;
	
	//To add a Admin to database
	public ResponseEntity<Admin> addAdmin(Admin admin) throws AdminException{
		if( repository.existsById(admin.getAdminId())) {
			throw new AdminException("this id alredy exists");
		}
			
		repository.save(admin);
		return new ResponseEntity<Admin>(admin, HttpStatus.CREATED);
	}
	
	//update Admin details to database
	public ResponseEntity<Admin> updateAdmin(Admin Admin){
		repository.save(Admin);
		return new ResponseEntity<Admin>(Admin, HttpStatus.CREATED);
		
	}
	
	//delete a Admin 
	public ResponseEntity<String> deleteAdmin(String id) throws AdminException{
		if(!repository.existsById(id)) {
			throw new AdminException("This Admin doesn't exist");
		}
		repository.deleteById(id);
		return  new ResponseEntity<String>("Admin deleted successfully",  HttpStatus.OK);
	}
	//view all Admins
	public ResponseEntity<List<Admin>> viewAllAdmin() throws AdminException{
		List<Admin> allAdmins = repository.findAll();
		if ( allAdmins.size() == 0) {
			throw new AdminException("No Admin exits");
		}
		return  new ResponseEntity<List<Admin>>(allAdmins,  HttpStatus.OK);
	}
	
	//Admin authentication
	public ResponseEntity<Admin> AdminAuthentication(String id, String password) throws AdminException{
		
		Admin admin = repository.AdminAuthentication(id, password);
		if (admin == null) {
			throw new AdminException("invalid credentials for admin");
		}
		return new ResponseEntity<Admin>(admin,  HttpStatus.OK);
	}

}
